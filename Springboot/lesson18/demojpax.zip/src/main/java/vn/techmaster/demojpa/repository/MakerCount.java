package vn.techmaster.demojpa.repository;

public record MakerCount(String maker, long count) {}