insert into post6 (title) values ('Spread love everywhere you go. Let no one ever come to you without leaving happier');
insert into post6 (title) values ('The future belongs to those who believe in the beauty of their dreams');
insert into post6 (title) values ('Tell me and I forget. Teach me and I remember. Involve me and I learn');
insert into post6 (title) values ('Your time is limited, so don''t waste it living someone else''s life');
insert into post6 (title) values ('Bạn hèn kém vì bạn quỳ xuống');
insert into post6 (title) values ('To accept insults and injuries. To accept being slighted, forgotten and disliked.');