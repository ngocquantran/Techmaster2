insert into REGISTRATION (id, first, last, age) values (1, 'Trịnh', 'Cường', 46);
insert into REGISTRATION (id, first, last, age) values (2, 'Đoàn', 'Dũng', 36);